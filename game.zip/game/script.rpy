# MISSION EMPREINTE - Jeu pédagogique Ren'Py pour collégiens

init -2 python:
    config.screen_width = 1280
    config.screen_height = 720

define e = Character("Élève", color="#9fe8ff")
define n = Character(None)
default score = 0
default erreurs = 0
default niveau = 1
default use_sfx = True
default use_music = True

init python:
    import random
    def shuffled_menu(choices):
        result = list(choices)
        random.shuffle(result)
        return result
    def play_optional_sound(filename):
        if use_sfx and renpy.loadable(filename):
            renpy.sound.play(filename)
    def start_optional_music(filename):
        if use_music and renpy.loadable(filename):
            renpy.music.play(filename, loop=True, fadein=1.5)
    def stop_optional_music():
        renpy.music.stop(fadeout=1.0)

image bg mission = im.Scale("images/background.png", 1280, 720)
image logo mission = im.Scale("images/logo.png", 900, 323)

style say_dialogue:
    size 25
style say_label:
    size 26

screen choice(items):
    style_prefix "choice"
    vbox:
        xalign 0.5
        yalign 0.62
        xsize 1020
        spacing 10
        for i in items:
            textbutton i.caption:
                action i.action
                xsize 1020
                xpadding 24
                ypadding 12
                text_size 22
                text_text_align 0.5
                text_xalign 0.5

screen hud():
    frame:
        xalign 0.02
        yalign 0.02
        padding (12, 8)
        background "#07162ccc"
        text "Score : [score]/4   Erreurs : [erreurs]   Niveau : [niveau]/4" size 19 color "#ffffff"

screen card(txt):
    modal True
    frame:
        xalign 0.5
        yalign 0.5
        xsize 1040
        xmaximum 1040
        ymaximum 610
        padding (28, 22)
        background "#07162cee"
        vbox:
            xfill True
            spacing 18
            text txt:
                size 24
                xmaximum 970
                xalign 0.5
                text_align 0.5
                color "#ffffff"
            textbutton "CONTINUER":
                action Return()
                xalign 0.5
                text_size 21

screen audio_settings():
    frame:
        xalign 0.98
        yalign 0.02
        padding (10, 6)
        background "#07162ccc"
        hbox:
            spacing 7
            text "Effets" size 16
            textbutton ("ON" if use_sfx else "OFF"):
                action ToggleVariable("use_sfx")
                text_size 16
            text "Musique" size 16
            textbutton ("ON" if use_music else "OFF"):
                action [ToggleVariable("use_music"), Function(renpy.music.set_pause, use_music)]
                text_size 16

label start:
    $ score = 0
    $ erreurs = 0
    $ niveau = 1
    scene bg mission
    show screen hud
    show screen audio_settings
    $ start_optional_music("audio/theme.ogg")
    show logo mission at truecenter
    with dissolve
    $ renpy.pause(2.0)
    hide logo mission
    with dissolve
    call screen card("Bienvenue dans MISSION EMPREINTE !\n\nDécouvre les traces laissées en ligne et apprends à construire une identité numérique maîtrisée.\n\nQuatre situations t'attendent.")
    jump question1

label question1:
    $ niveau = 1
    scene bg mission
    show screen hud
    show screen audio_settings
    $ play_optional_sound("audio/level.ogg")
    n "Niveau 1 - La publication effacée"
    n "Tu supprimes une photo quelques minutes après l'avoir publiée."
    e "Peux-tu être certain qu'elle a totalement disparu ?"
    $ opts = shuffled_menu([
        ("Oui, supprimer signifie qu'aucune copie ne peut exister", "q1_r1"),
        ("Non, quelqu'un a pu la copier ou la capturer avant sa suppression", "q1_r2"),
        ("Oui, si le compte est privé", "q1_r3"),
    ])
    menu:
        "[opts[0][0]]":
            jump expression opts[0][1]
        "[opts[1][0]]":
            jump expression opts[1][1]
        "[opts[2][0]]":
            jump expression opts[2][1]

label q1_r1:
    $ erreurs += 1
    $ play_optional_sound("audio/error.ogg")
    n "Une capture d'écran, un téléchargement ou un partage a pu être effectué."
    jump q1_explication

label q1_r2:
    $ score += 1
    $ play_optional_sound("audio/correct.ogg")
    n "Exact : la suppression réduit la diffusion mais ne garantit pas l'absence de copies."
    jump q1_explication

label q1_r3:
    $ erreurs += 1
    $ play_optional_sound("audio/error.ogg")
    n "Un abonné autorisé peut malgré tout enregistrer ou transmettre le contenu."
    jump q1_explication

label q1_explication:
    call screen card("À RETENIR\n\nAvant de publier, imagine que le contenu puisse être enregistré. La suppression est utile, mais elle ne permet pas toujours de récupérer toutes les copies.")
    jump question2

label question2:
    $ niveau = 2
    scene bg mission
    show screen hud
    show screen audio_settings
    $ play_optional_sound("audio/level.ogg")
    n "Niveau 2 - Le pseudonyme"
    n "Tu utilises un pseudonyme, mais ton profil montre ton collège, ta ville, tes activités et plusieurs photos."
    e "Es-tu réellement anonyme ?"
    $ opts = shuffled_menu([
        ("Oui, le pseudonyme suffit toujours à cacher mon identité", "q2_r1"),
        ("Pas forcément : les informations et photos peuvent permettre de m'identifier", "q2_r2"),
        ("Oui, si mon pseudonyme ne ressemble pas à mon prénom", "q2_r3"),
    ])
    menu:
        "[opts[0][0]]":
            jump expression opts[0][1]
        "[opts[1][0]]":
            jump expression opts[1][1]
        "[opts[2][0]]":
            jump expression opts[2][1]

label q2_r1:
    $ erreurs += 1
    $ play_optional_sound("audio/error.ogg")
    n "Le recoupement de plusieurs indices peut permettre de reconnaître une personne."
    jump q2_explication

label q2_r2:
    $ score += 1
    $ play_optional_sound("audio/correct.ogg")
    n "Exact : l'identité peut être révélée par l'ensemble des petits indices publiés."
    jump q2_explication

label q2_r3:
    $ erreurs += 1
    $ play_optional_sound("audio/error.ogg")
    n "Le nom du compte n'est qu'un indice parmi beaucoup d'autres."
    jump q2_explication

label q2_explication:
    call screen card("À RETENIR\n\nUn pseudonyme limite l'affichage du nom, mais ne rend pas invisible. Évite de cumuler des indices précis sur ton identité, tes habitudes et tes lieux.")
    jump question3

label question3:
    $ niveau = 3
    scene bg mission
    show screen hud
    show screen audio_settings
    $ play_optional_sound("audio/level.ogg")
    n "Niveau 3 - Le vieux commentaire"
    n "Un ancien commentaire agressif réapparaît plusieurs années après sa publication et ne correspond plus à la personne que tu es devenue."
    e "Quel enseignement en tirer ?"
    $ opts = shuffled_menu([
        ("Les anciennes publications ne comptent jamais", "q3_r1"),
        ("Avant de publier, il faut penser au public actuel mais aussi au public futur", "q3_r2"),
        ("Il suffit de changer régulièrement de téléphone", "q3_r3"),
    ])
    menu:
        "[opts[0][0]]":
            jump expression opts[0][1]
        "[opts[1][0]]":
            jump expression opts[1][1]
        "[opts[2][0]]":
            jump expression opts[2][1]

label q3_r1:
    $ erreurs += 1
    $ play_optional_sound("audio/error.ogg")
    n "Un ancien contenu peut être retrouvé et interprété sans connaître le contexte."
    jump q3_explication

label q3_r2:
    $ score += 1
    $ play_optional_sound("audio/correct.ogg")
    n "Exact : ton empreinte numérique se construit dans le temps."
    jump q3_explication

label q3_r3:
    $ erreurs += 1
    $ play_optional_sound("audio/error.ogg")
    n "Changer d'appareil ne supprime pas les contenus stockés en ligne."
    jump q3_explication

label q3_explication:
    call screen card("À RETENIR\n\nUne publication peut voyager dans le temps et changer de contexte. Relis-toi, évite les messages écrits sous le coup de la colère et corrige tes erreurs.")
    jump question4

label question4:
    $ niveau = 4
    scene bg mission
    show screen hud
    show screen audio_settings
    $ play_optional_sound("audio/level.ogg")
    n "Niveau 4 - Faire le point"
    n "Tu souhaites mieux maîtriser les informations visibles à ton sujet sur Internet."
    e "Quelle démarche est la plus utile ?"
    $ opts = shuffled_menu([
        ("Ne rien vérifier pour ne pas s'inquiéter", "q4_r1"),
        ("Rechercher ce qui est public, contrôler les paramètres et demander la suppression des contenus gênants", "q4_r2"),
        ("Créer encore plus de comptes pour cacher les anciens", "q4_r3"),
    ])
    menu:
        "[opts[0][0]]":
            jump expression opts[0][1]
        "[opts[1][0]]":
            jump expression opts[1][1]
        "[opts[2][0]]":
            jump expression opts[2][1]

label q4_r1:
    $ erreurs += 1
    $ play_optional_sound("audio/error.ogg")
    n "Ignorer ses traces empêche de corriger les informations indésirables."
    jump q4_explication

label q4_r2:
    $ score += 1
    $ play_optional_sound("audio/correct.ogg")
    n "Très bon plan : observation, réglages et demandes de retrait se complètent."
    jump q4_explication

label q4_r3:
    $ erreurs += 1
    $ play_optional_sound("audio/error.ogg")
    n "Multiplier les comptes crée généralement davantage de traces."
    jump q4_explication

label q4_explication:
    call screen card("À RETENIR\n\nVérifie périodiquement tes profils publics, ferme les comptes inutilisés, règle leur visibilité et demande de l'aide pour faire retirer un contenu problématique.")
    jump bilan_final

label bilan_final:
    scene bg mission
    show screen hud
    show screen audio_settings
    $ play_optional_sound("audio/victory.ogg")
    if score == 4:
        $ msg = "EXPERT : tu as acquis les quatre bons réflexes !"
    elif score >= 2:
        $ msg = "BON NIVEAU : encore quelques réflexes à consolider."
    else:
        $ msg = "EN APPRENTISSAGE : le débrief va t'aider à progresser."
    call screen card("BILAN DE LA MISSION\n\nScore : [score] / 4     Erreurs : [erreurs]\n\n[msg]\n\nLES 4 RÉFLEXES\n1. Traces : une publication peut être copiée.\\n2. Pseudo : il protège le nom, pas toute l'identité.\\n3. Réputation : réfléchir au public présent et futur.\\n4. Maîtrise : vérifier, régler, supprimer et demander de l'aide.")
    menu:
        "Rejouer":
            jump start
        "Quitter":
            $ stop_optional_music()
            $ renpy.quit()
